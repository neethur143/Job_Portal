package com.niit.Applicant.dao;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.niit.Applicant.dao.Applicant;
import com.niit.SqlConnect.SqlConnection;

import java.sql.*;

public class ApplicantDao {

	static Connection con = null;

	public static List<Applicant> list(String val) throws SQLException {

		List<Applicant> applicants = new ArrayList<Applicant>();
		try {
			con = SqlConnection.dbConnector();
			Statement statement = con.createStatement();
			System.out.println(val);
			var userflag=0;
			String query="";
			if(val.equals("admin@gmail.com")) { userflag=1;
			System.out.print(userflag);
			}else {
				System.out.print(userflag);
			}
			if(val.equals("admin@gmail.com")) {
				query = "select CompanyName,JobPost,Email,FullName,MobileNo,qualification,applyid from appliedjobs" ;
			} else {
				System.out.println("Yes.. User not admin");
				
				query = "select CompanyName,JobPost,Email,FullName,MobileNo,qualification,applyid from appliedjobs where CompanyName="+"'"+val+"'" ;// where CompanyName=" + "'" + val +"'
				
			}
			
			System.out.println(query);
			ResultSet resultSet = statement.executeQuery(query);
			if(con!=null) System.out.println("conn not null");
			while (resultSet.next()) {
				Applicant a = new Applicant();
				System.out.println("Reached applicantDao Inner loop");
				a.setCompanyName(resultSet.getString("CompanyName"));
				a.setJobPost(resultSet.getString("JobPost"));
				a.setEmail(resultSet.getString("Email"));
				a.setFullName(resultSet.getString("FullName"));
				a.setMobileNo(resultSet.getString("MobileNo"));
				a.setqualification(resultSet.getString("qualification"));
				a.setapplyid(resultSet.getString("applyid"));
				System.out.println(a.getqualification());
				applicants.add(a);
				
			}
			con.close();
			return applicants;
		} catch (Exception e) {System.out.println(e);}
		return null;

	}

}
package com.niit.Applicant.dao;

public class Applicant {
	private String JobPost;
	private String Email;
	private String FullName;
	private String MobileNo;
	private String qualification;
	private String CompanyName;
	private String applyid;
	
	public String getJobPost() {
		return JobPost;
	}
	public void setJobPost(String JobPost) {
		this.JobPost = JobPost;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String Email) {
		this.Email = Email;
	}
	public String getFullName() {
		return FullName;
	}
	public void setFullName(String FullName) {
		this.FullName = FullName;
	}
	public String getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(String MobileNo) {
		this.MobileNo = MobileNo;
	}
	public String getqualification() {
		return qualification;
	}
	public void setqualification(String qualification) {
		this.qualification = qualification;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String CompanyName) {
		this.CompanyName = CompanyName;
	}
	public String getapplyid() {
		return applyid;
	}
	public void setapplyid(String applyid) {
		this.applyid = applyid;
	}
}

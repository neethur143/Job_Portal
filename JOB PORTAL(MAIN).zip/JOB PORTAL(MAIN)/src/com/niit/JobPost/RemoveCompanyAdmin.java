package com.niit.JobPost;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.JobBean.dao.CompUserShowDao;

/**
 * Servlet implementation class RemoveCompanyAdmin
 */
@WebServlet("/RemoveCompanyAdmin")
public class RemoveCompanyAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveCompanyAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String companyname=request.getParameter("id5");
		String comp=request.getParameter("comp");
		try {
				
				
				CompUserShowDao c = new CompUserShowDao();
				PrintWriter p = response.getWriter();
				if(c.removeCompanyAdmin(companyname)!=0) {
					p.println("<script>alert('Company Removed')</script>");
					response.setHeader("Refresh", "1;CompanyShow");
			 	}else {
			 		p.println("<script>alert('Failed')</script>");
			 		response.setHeader("Refresh", "1;AdminTest.jsp");
			 		
			 	}
		}
			catch (Exception e) {System.out.println(e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

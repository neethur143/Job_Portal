package com.niit.JobPost;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.JobBean.Job;
import com.niit.JobBean.dao.JobDao;

/**
 * Servlet implementation class RemoveJob
 */
@WebServlet("/RemoveJob")
public class RemoveJob extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveJob() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Jpost=request.getParameter("id");
		String Company=request.getParameter("comp");
		System.out.println("id"+Jpost);
		System.out.println("c-mail"+Company);
		try {
			
			JobDao d=new JobDao();
			PrintWriter p = response.getWriter();
			if(d.removeJob(Jpost,Company)!=0) {
				p.println("<script>alert('Job Removed')</script>");
				response.setHeader("Refresh", "1;Manage");
		 	}else {
		 		p.println("<script>alert('Failed')</script>");
		 		response.setHeader("Refresh", "1;CompanyPage.jsp");
		 		
		 	}
	}
		catch (Exception e) {System.out.println(e);}
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

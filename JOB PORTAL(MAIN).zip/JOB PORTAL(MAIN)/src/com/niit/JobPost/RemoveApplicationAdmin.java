package com.niit.JobPost;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.JobBean.dao.JobDao;

/**
 * Servlet implementation class RemoveApplicationAdmin
 */
@WebServlet("/RemoveApplicationAdmin")
public class RemoveApplicationAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveApplicationAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String applyid=request.getParameter("id2");
		String Company=request.getParameter("comp");
		System.out.println("id+comp"+applyid+Company);
		try {
				
				JobDao d=new JobDao();
				PrintWriter p = response.getWriter();
				if(d.removeApplicationAdmin(applyid,Company)!=0) {
					p.println("<script>alert('Application Removed')</script>");
					response.setHeader("Refresh", "1;Applicants");
			 	}else {
			 		p.println("<script>alert('Failed')</script>");
			 		response.setHeader("Refresh", "1;AdminTest.jsp");
			 		
			 	}
		}
			catch (Exception e) {System.out.println(e);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package com.niit.JobPost;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.JobBean.dao.JobDao;

/**
 * Servlet implementation class RemoveJobPostAdmin
 */
@WebServlet("/RemoveJobPostAdmin")
public class RemoveJobPostAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveJobPostAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String loc=request.getParameter("id20");
		String post=request.getParameter("id21");
		String vac=request.getParameter("id22");
		String email=request.getParameter("id23");
		
		System.out.println("id+comp"+loc+post+vac+email);
		try {
				
				JobDao d=new JobDao();
				PrintWriter p = response.getWriter();
				if(d.removeJobPostAdmin(loc,post,email)!=0) {
					p.println("<script>alert('JobPost Removed')</script>");
					response.setHeader("Refresh", "1;JobPostShow");
			 	}else {
			 		p.println("<script>alert('Failed')</script>");
			 		response.setHeader("Refresh", "1;AdminTest.jsp");
			 		
			 	}
		}
			catch (Exception e) {System.out.println(e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

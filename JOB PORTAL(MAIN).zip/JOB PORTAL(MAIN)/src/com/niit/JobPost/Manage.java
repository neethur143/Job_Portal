package com.niit.JobPost;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.Applicant.dao.Applicant;
import com.niit.Applicant.dao.ApplicantDao;
import com.niit.JobBean.Job;
import com.niit.JobBean.dao.JobDao;

/**
 * Servlet implementation class Manage
 */
@WebServlet("/Manage")
public class Manage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Manage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String compMail = (String)request.getSession(false).getAttribute("username");
		
		response.setContentType("text/html");  
		 try {List<Job> jobs =JobDao.listComp(compMail);
		 request.setAttribute("JobList",jobs);
		 request.getRequestDispatcher("Manage.jsp").forward(request, response);
		 
		 } catch (SQLException e) {System.out.println(e);}	
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package com.niit.tests.testObjects;

public class Question {
    private String eid;
    private String qid;
    private String question;
    private int choice;
    private int sn;
    
    public String getEid() {
        return eid;
    }
    public void setEid(String eid) {
        this.eid = eid;
    }
    public String getQid() {
        return qid;
    }
    public void setQid(String qid) {
        this.qid = qid;
    }
    public String getQuestion() {
        return question;
    }
    public void setQuestion(String question) {
        this.question = question;
    }
    public int getChoice() {
        return choice;
    }
    public void setChoice(int choice) {
        this.choice = choice;
    }
    public int getSn() {
        return sn;
    }
    public void setSn(int sn) {
        this.sn = sn;
    }
}

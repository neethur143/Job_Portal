package com.niit.tests.testObjects;

public class Option {
    private String qid;
    private String option;
    private String optionid;
    
    public String getQid() {
        return qid;
    }
    public void setQid(String qid) {
        this.qid = qid;
    }
    public String getOption() {
        return option;
    }
    public void setOption(String option) {
        this.option = option;
    }
    public String getOptionid() {
        return optionid;
    }
    public void setOptionid(String optionid) {
        this.optionid = optionid;
    }
    
}

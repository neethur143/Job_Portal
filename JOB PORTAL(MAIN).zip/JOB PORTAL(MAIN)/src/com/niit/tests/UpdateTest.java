package com.niit.tests;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.tests.testDao.TestDao;
import com.niit.tests.testObjects.History;
import com.niit.tests.testObjects.Option;
import com.niit.tests.testObjects.Question;
import com.niit.tests.testObjects.Quiz;

/**
 * Servlet implementation class Update
 */
@WebServlet("/UpdateTest")
public class UpdateTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateTest() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String qvar = request.getParameter("q");
	    
	    if(qvar.equals("quiz")) {
            int step = Integer.parseInt(request.getParameter("step"));
            String eid = request.getParameter("eid");
            int sn = Integer.parseInt(request.getParameter("n"));
            int total = Integer.parseInt(request.getParameter("t"));
            String ans = request.getParameter("ans");
            String qid = request.getParameter("qid");

//            String email = "ali@gmail.com";
            String email = (String) request.getSession().getAttribute("username");

            
            try {
                List<Question> questionsList = TestDao.questionsList(eid, sn);
                
                request.getSession().setAttribute("questionsList", questionsList);
                
                

                
                String ansid = TestDao.getAnsId(qid);
                if(ans.equals(ansid)) {
                    int right = TestDao.getRight(eid);
                    
                    if(sn-1 == 1) {
                        TestDao.delHistory(email, eid);
                        TestDao.setHistory(email, eid);
                    }
                    List<History> historyList = TestDao.getHistoryList(eid, email);
                    int s = historyList.get(0).getScore();
                    int r = historyList.get(0).getRight();
                    r++;
                    s = s + right;
                    TestDao.updateHistoryRight(email, eid, s, sn, r);
                } else {
                    int wrong = TestDao.getWrong(eid);
                    if(sn-1 == 1) {
                        TestDao.delHistory(email, eid);
                        TestDao.setHistory(email, eid);                        
                    }
                    List<History> historyList = TestDao.getHistoryList(eid, email);
                    int s = historyList.get(0).getScore();
                    int w = historyList.get(0).getWrong();
                    w++;
                    s = s - wrong;
                    TestDao.updateHistoryWrong(email, eid, s, sn, w);
                }
                if(sn != total+1) {
                        qid = questionsList.get(0).getQid();
                        List<Option> optionsList = TestDao.optionsList(qid);                
                        request.getSession().setAttribute("optionsList", optionsList);
                       response.sendRedirect("tests/testportal.jsp?q="+qvar+"&step="+step+"&eid="+eid+"&n="+sn+"&t="+total+"&qid="+qid);
                } else {
                    List<History> historyList = TestDao.getHistoryList(eid, email);
                    int s = historyList.get(0).getScore();
                    int rowCount = TestDao.rowCountRank(email);
                    if(rowCount == 0) {
                        TestDao.setRank(email, s);
                    } else {
                        int sun = TestDao.getScoreRank(email);
                        sun = s + sun;
                        TestDao.updateRank(email, sun);
                    }
                    request.getSession().setAttribute("historyList", historyList);
                    response.sendRedirect("tests/testportal.jsp?q=result&eid="+eid+"&total="+total+"");
                    
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
	}

	
}

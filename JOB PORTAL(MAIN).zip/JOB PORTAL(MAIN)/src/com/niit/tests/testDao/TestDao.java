package com.niit.tests.testDao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.niit.JobBean.Job2;
import com.niit.SqlConnect.SqlConnection;
import com.niit.tests.testObjects.History;
import com.niit.tests.testObjects.Option;
import com.niit.tests.testObjects.Question;
import com.niit.tests.testObjects.Quiz;
import com.niit.tests.testObjects.Rank;

public class TestDao {
    static Connection con=null;
    public static List<Quiz> quizList() throws SQLException {

        List<Quiz> quizList = new ArrayList<>();
        try {
            con = SqlConnection.dbConnectorTests();
            Statement statement = con.createStatement();
            String query = "SELECT * FROM quiz ORDER BY date DESC";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                Quiz q = new Quiz();
                
                q.setEid(resultSet.getString("eid"));
                q.setTitle(resultSet.getString("title"));
                q.setRight(resultSet.getInt("right"));
                q.setWrong(resultSet.getInt("wrong"));
                q.setTotal(resultSet.getInt("total"));
                q.setTag(resultSet.getString("tag"));
                q.setDate(resultSet.getTimestamp("date"));
                q.setTime(resultSet.getInt("time"));

                quizList.add(q);
            }
            return quizList;
        } catch (Exception e) {System.out.println(e);}
        return null;

    }
    public static List<History> historyListOfEmail(String email) throws SQLException {

        List<History> historyList = new ArrayList<>();
        try {
            con = SqlConnection.dbConnectorTests();
            Statement statement = con.createStatement();
            String query = "SELECT * FROM history WHERE email = '"+ email +"'ORDER BY date DESC";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                History h = new History();
                
                h.setEmail(resultSet.getString("email"));
                h.setEid(resultSet.getString("eid"));
                h.setScore(resultSet.getInt("score"));
                h.setLevel(resultSet.getInt("level"));
                h.setRight(resultSet.getInt("right"));
                h.setWrong(resultSet.getInt("wrong"));
                h.setDate(resultSet.getTimestamp("date"));

                historyList.add(h);
            }
            return historyList;
        } catch (Exception e) {System.out.println(e);}
        return null;

    }
    public static List<Question> questionsList(String eid, int sn) throws SQLException {

        List<Question> questionsList = new ArrayList<>();
        try {
            con = SqlConnection.dbConnectorTests();
            Statement statement = con.createStatement();
            String query = "SELECT * FROM questions WHERE eid='"+eid+"' AND sn='"+sn+"'";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                Question q = new Question();
                
                q.setEid(resultSet.getString("eid"));
                q.setQid(resultSet.getString("qid"));
                q.setQuestion(resultSet.getString("qns"));
                q.setChoice(resultSet.getInt("choice"));
                q.setSn(resultSet.getInt("sn"));

                questionsList.add(q);
            }
            return questionsList;
        } catch (Exception e) {System.out.println(e);}
        return null;

    }
    public static List<Option> optionsList(String qid) throws SQLException {

        List<Option> optionsList = new ArrayList<>();
        try {
            con = SqlConnection.dbConnectorTests();
            Statement statement = con.createStatement();
            String query = "SELECT * FROM options WHERE qid='"+qid+"'";
//            System.out.println(qid);
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                Option q = new Option();
               
                q.setQid(resultSet.getString("qid"));
                q.setOption(resultSet.getString("option"));
                q.setOptionid(resultSet.getString("optionid"));

                optionsList.add(q);
            }
            return optionsList;
        } catch (Exception e) {System.out.println(e);}
        return null;

    }
    public static String getAnsId(String qid) {
        try {
            con = SqlConnection.dbConnectorTests();
            String ansid = null;
            Statement statement = con.createStatement();
            String query = "SELECT * FROM answer WHERE qid='"+qid+"'";
//            System.out.println(qid);
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                ansid = resultSet.getString("ansid");
            }
            return ansid;
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }
    public static int getRight(String eid) {
        try {
            con = SqlConnection.dbConnectorTests();
            int right = 0;
            Statement statement = con.createStatement();
            String query = "SELECT * FROM quiz WHERE eid='"+eid+"'";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                right = resultSet.getInt("right");
            }
            return right;
        } catch (Exception e) {
            System.out.println(e);
            return 0;
        }
    }
    public static int getWrong(String eid) {
        try {
            con = SqlConnection.dbConnectorTests();
            int wrong = 0;
            Statement statement = con.createStatement();
            String query = "SELECT * FROM quiz WHERE eid='"+eid+"'";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                wrong = resultSet.getInt("right");
            }
            return wrong;
        } catch (Exception e) {
            System.out.println(e);
            return 0;
        }
    }
    public static void setHistory(String email, String eid) {
        try {
            con = SqlConnection.dbConnectorTests();
            String query = "INSERT INTO history VALUES (?,?,?,?,?,?,?)";
            PreparedStatement st = con.prepareStatement(query);
            st.setString(1, email);
            st.setString(2, eid);
            st.setInt(3, 0);
            st.setInt(4, 0);
            st.setInt(5, 0);
            st.setInt(6, 0);
            st.setTimestamp(7, new Timestamp(System.currentTimeMillis()));
            int i = st.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public static List<History> getHistoryList(String eid, String email) throws SQLException {

        List<History> historyList = new ArrayList<>();
        try {
            con = SqlConnection.dbConnectorTests();
            Statement statement = con.createStatement();
            String query = "SELECT * FROM history WHERE eid='"+eid+"' and email='"+email+"'";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                History h = new History();
               
                h.setEmail(resultSet.getString("email"));
                h.setEid(resultSet.getString("eid"));
                h.setScore(resultSet.getInt("score"));
                h.setLevel(resultSet.getInt("level"));
                h.setRight(resultSet.getInt("right"));
                h.setWrong(resultSet.getInt("wrong"));
                h.setDate(resultSet.getTimestamp("date"));

                historyList.add(h);
            }
            return historyList;
        } catch (Exception e) {System.out.println(e);}
        return null;
    }
    public static List<Rank> getRankList() throws SQLException {

        List<Rank> rankList = new ArrayList<>();
        try {
            con = SqlConnection.dbConnectorTests();
            Statement statement = con.createStatement();
            String query = "SELECT * FROM rank";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                Rank h = new Rank();
               
                h.setEmail(resultSet.getString("email"));
                h.setScore(resultSet.getInt("score"));
                h.setTime(resultSet.getTimestamp("time"));

                rankList.add(h);
            }
            return rankList;
        } catch (Exception e) {System.out.println(e);}
        return null;
    }
    public static void updateHistoryRight(String email, String eid, int score, int level, int right) {
        try {
            con = SqlConnection.dbConnectorTests();
            String query = "UPDATE `history` SET `score`='"+score+"',`level`='"+level+"',`right`='"+right+"', date='"+new Timestamp(System.currentTimeMillis())+"'  WHERE  email = '"+email+"' AND eid = '"+eid+"'";

            PreparedStatement st = con.prepareStatement(query);
            int i = st.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public static void updateHistoryWrong(String email, String eid, int score, int level, int wrong) {
        try {
            con = SqlConnection.dbConnectorTests();
            String query = "UPDATE `history` SET `score`='"+score+"',`level`='"+level+"',`wrong`='"+wrong+"', date='"+new Timestamp(System.currentTimeMillis())+"'  WHERE  email = '"+email+"' AND eid = '"+eid+"'";

            PreparedStatement st = con.prepareStatement(query);
            int i = st.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public static int rowCountRank(String email) {
        try {
            con = SqlConnection.dbConnectorTests();
            String query = "SELECT COUNT(*) FROM rank WHERE email = '"+email+"'";

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            rs.next();
            int count = rs.getInt(1);
            return count;
        } catch (Exception e) {
            System.out.println(e);
            return 0;
        }
    }
    public static void setRank(String email, int score) {
        try {
            con = SqlConnection.dbConnectorTests();
            String query = "INSERT INTO rank VALUES (?,?,?)";
            PreparedStatement st = con.prepareStatement(query);
            st.setString(1, email);
            st.setInt(2, score);
            st.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            int i = st.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public static void updateRank(String email, int score) {
        try {
            con = SqlConnection.dbConnectorTests();
            String query = "UPDATE `rank` SET `score`='"+score+"' WHERE  email = '"+email+"'";

            PreparedStatement st = con.prepareStatement(query);
            int i = st.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    //SELECT * FROM rank WHERE email='$email'"
    public static int getScoreRank(String email) {
        try {
            con = SqlConnection.dbConnectorTests();
            int score = 0;
            Statement statement = con.createStatement();
            String query = "SELECT * FROM rank WHERE email='"+email+"'";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                score = resultSet.getInt("score");
            }
            return score;
        } catch (Exception e) {
            System.out.println(e);
            return 0;
        }
    }
    public static void delHistory(String email, String eid) {
        // TODO Auto-generated method stub
        try {
            con = SqlConnection.dbConnectorTests();
            String query = "DELETE FROM history WHERE email = '"+email+"' AND eid = '"+eid+"'";

            PreparedStatement st = con.prepareStatement(query);
            int i = st.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

package com.niit.tests;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.JobBean.Job2;
import com.niit.JobBean.dao.JobDao2;
import com.niit.tests.testDao.TestDao;
import com.niit.tests.testObjects.History;
import com.niit.tests.testObjects.Option;
import com.niit.tests.testObjects.Question;
import com.niit.tests.testObjects.Quiz;

/**
 * Servlet implementation class Tests
 */
@WebServlet("/Tests")
public class Tests extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Tests() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String qvar = request.getParameter("q");
	    if(qvar.equals("1")) {
	        try {
	            List<Quiz> quizList = TestDao.quizList();
	            request.getSession().setAttribute("quizList",quizList);
	            response.sendRedirect("tests/testportal.jsp?q="+qvar);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    } else if(qvar.equals("quiz")) {
	        int step = Integer.parseInt(request.getParameter("step"));
	        String eid = request.getParameter("eid");
	        int n = Integer.parseInt(request.getParameter("n"));
	        int t = Integer.parseInt(request.getParameter("t"));
	        try {
                List<Question> questionsList = TestDao.questionsList(eid, n);
                request.getSession().setAttribute("questionsList", questionsList);
                String qid = questionsList.get(0).getQid();
                
                List<Option> optionsList = TestDao.optionsList(qid);                
                request.getSession().setAttribute("optionsList", optionsList);
                
                response.sendRedirect("tests/testportal.jsp?q="+qvar+"&step="+step+"&eid="+eid+"&n="+n+"&t="+t+"&qid="+qid);
            } catch (SQLException e) {
                e.printStackTrace();
            }
	    } else if(qvar.equals("2")) {
	        try {
	            String email = (String) request.getSession().getAttribute("username");
	            
	            
	            
	            
	            
	            
	            
	            List<History> historyList = TestDao.historyListOfEmail(email);
	            request.getSession().setAttribute("historyList",historyList);
	            
	            List<Quiz> quizList = TestDao.quizList();
                request.getSession().setAttribute("quizList",quizList);
                
                response.sendRedirect("tests/testportal.jsp?q="+qvar);
            } catch (Exception e) {
                e.printStackTrace();
            }
	    } else if(qvar.equals("3")) {
	        
	    }
	    
	}


}

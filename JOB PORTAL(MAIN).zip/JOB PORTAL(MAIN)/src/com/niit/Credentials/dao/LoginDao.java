package com.niit.Credentials.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.niit.SqlConnect.SqlConnection;

public class LoginDao  {

	String query = "select * from employee where Uemail=? and Password=?";
	Connection con=null;
	public boolean validate(String E_mail, String pass) {
		try {
			con=SqlConnection.dbConnector();
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1,E_mail);
			st.setString(2, pass);
			ResultSet rs = st.executeQuery();
				if (rs.next()) 
				{return true;}
			} 
		catch (Exception e){System.out.println(e);}
		return false;

	
	}	
	public String fullname(String val) throws SQLException {
      try {
          con = SqlConnection.dbConnector();
          Statement statement = con.createStatement();
          String query = "select Ufname,Ulname from employee where Uemail=" + "'" + val +"'";
          ResultSet resultSet = statement.executeQuery(query);
          String fullname = "";
          while (resultSet.next()) {
              fullname = resultSet.getString("Ufname") + resultSet.getString("Ulname");
          }
          return fullname;
      } catch (Exception e) {System.out.println(e);}
      return null;

  }
}

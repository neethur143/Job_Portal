package com.niit.JobBean;

public class User {
	private String Uemail;
	private String Ufname;
	private String Ulname;
	private String no;
	
	public String getUemail() {
		return Uemail;
	}
	public void setUemail(String Uemail) {
		this.Uemail = Uemail;
	}
	public String getUfname() {
		return Ufname;
	}
	public void setUfname(String Ufname) {
		this.Ufname = Ufname;
	}
	public String getUlname() {
		return Ulname;
	}
	public void setUlname(String Ulname) {
		this.Ulname = Ulname;
	}
	public String getno() {
		return no;
	}
	public void setno(String no) {
		this.no = no;
	}
}

package com.niit.JobBean;

public class Comp {

private String companyname;
private String cEmail;
private String web;

	
	public String getCname() {
		return companyname;
	}
	public void setCname(String companyname) {
		this.companyname = companyname;
	}
	public String getcEmail() {
		return cEmail;
	}
	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}
	public String getweb() {
		return web;
	}
	public void setweb(String web) {
		this.web = web;
	}
	
}


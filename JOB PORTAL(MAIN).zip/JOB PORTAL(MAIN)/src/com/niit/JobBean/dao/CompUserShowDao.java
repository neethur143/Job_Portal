package com.niit.JobBean.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.niit.JobBean.Comp;
import com.niit.JobBean.Job;
import com.niit.JobBean.User;
import com.niit.SqlConnect.SqlConnection;

public class CompUserShowDao {
	static Connection con = null;

	public static List<Comp> listComp() throws SQLException {

		List<Comp> comp = new ArrayList<Comp>();
		try {
			con = SqlConnection.dbConnector();
			Statement statement = con.createStatement();
			String query = "select companyname,CompanyEmail,web from companies";
			ResultSet resultSet = statement.executeQuery(query);

			while (resultSet.next()) {
				Comp c = new Comp();
				c.setCname(resultSet.getString("companyname"));
				c.setcEmail(resultSet.getString("CompanyEmail"));
				c.setweb(resultSet.getString("web"));
				
				comp.add(c);
				
			}
			return comp;
		} catch (Exception e) {System.out.println(e);}
		return null;

	}
	public static List<User> listUser() throws SQLException {

		List<User> user = new ArrayList<User>();
		try {
			con = SqlConnection.dbConnector();
			Statement statement = con.createStatement();
			String query = "select Uemail,Ufname,Ulname,no from employee";
			ResultSet resultSet = statement.executeQuery(query);
			while (resultSet.next()) {
				User u = new User();
				u.setUemail(resultSet.getString("Uemail"));
				u.setUfname(resultSet.getString("Ufname"));
				u.setUlname(resultSet.getString("Ulname"));
				u.setno(resultSet.getString("no"));
				
				user.add(u);
				
			}
			return user;
		} catch (Exception e) {System.out.println(e);}
		return null;

	}
	public static List<Job> ListJobPosts() throws SQLException {

		List<Job> jobs = new ArrayList<Job>();
		try {
			con = SqlConnection.dbConnector();
			Statement statement = con.createStatement();
			ResultSet resultSet = statement.executeQuery("select * from jobpost");

			while (resultSet.next()) {
				Job j = new Job();
				j.setLocation(resultSet.getString("Location"));
				j.setFarea(resultSet.getString("FunctionalArea"));
				j.setJpost(resultSet.getString("JobPost"));
				j.setVacancy(resultSet.getInt("Vacany"));
				j.setSalary(resultSet.getString("Salary"));
				j.setIdate(resultSet.getString("interviewDate"));
				j.setItime(resultSet.getString("interviewTime"));
				j.setIplace(resultSet.getString("interviewPlace"));
				j.setqualification(resultSet.getString("qualification"));
				j.setCompany(resultSet.getString("email"));
				jobs.add(j);
				
			}
			return jobs;
		} catch (Exception e) {System.out.println(e);}
		return null;

	}
	public  int removeCompanyAdmin(String id) {
		try {
			con=SqlConnection.dbConnector();
			String Query="delete from companies where companyname="+"'"+id+"'";
			PreparedStatement st = con.prepareStatement(Query);
			int i = st.executeUpdate();
			System.out.println("Printing i : "+i);
			return i;
		}
		 catch (Exception e) {
			 System.out.println(e);
			 return 0;
		}
	}
	public  int removeUserAdmin(String applyid,String Company) {
		try {
			con=SqlConnection.dbConnector();
			String Query="delete from appliedjobs where applyid="+"'"+applyid+"'"+" and CompanyName="+"'"+Company+"'";
			System.out.println("Reached here : "+applyid+Company);
			PreparedStatement st = con.prepareStatement(Query);
			int i = st.executeUpdate();
			System.out.println("Printing i : "+i);
			return i;
		}
		 catch (Exception e) {
			 System.out.println(e);
			 return 0;
		}
	}
	public  int removeUser(String id) {
		try {
			con=SqlConnection.dbConnector();
			String Query="delete from employee where no="+"'"+id+"'";
			PreparedStatement st = con.prepareStatement(Query);
			int i = st.executeUpdate();
			System.out.println("Printing i : "+i);
			return i;
		}
		 catch (Exception e) {
			 System.out.println(e);
			 return 0;
		}
	}
}

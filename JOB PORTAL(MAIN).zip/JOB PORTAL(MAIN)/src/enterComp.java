

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.JobBean.Comp;
import com.niit.JobBean.dao.CompDao;

/**
 * Servlet implementation class enterComp
 */
@WebServlet("/enterComp")
public class enterComp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public enterComp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");  
		 try {
		 String s = request.getParameter("cname");
		 System.out.println(s);
		 System.out.println("reached enterComp class");
		 
		 
		 List<Comp> comp =CompDao.list(s);
		 
		
		 request.setAttribute("CompList",comp);
		 request.setAttribute("CompEmail",s);
		 System.out.println("comp attribute set"+s);
		 
		 request.getRequestDispatcher("CompanyHomePage.jsp").forward(request, response);
		 
		 } catch (Exception e) {System.out.println(e);}	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
